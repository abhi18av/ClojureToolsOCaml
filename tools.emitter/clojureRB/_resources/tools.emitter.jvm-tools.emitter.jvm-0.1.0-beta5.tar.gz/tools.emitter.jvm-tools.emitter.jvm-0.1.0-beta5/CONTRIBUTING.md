This is a [Clojure contrib] project.

Under the Clojure contrib [guidelines], this project cannot accept
pull requests. All patches must be submitted via [JIRA].

See [Contributing] and the [FAQ] on the Clojure development [wiki] for
more information on how to contribute.

[Clojure contrib]: http://dev.clojure.org/display/doc/Clojure+Contrib
[Contributing]: http://dev.clojure.org/display/community/Contributing
[FAQ]: http://dev.clojure.org/display/community/Contributing+FAQ
[JIRA]: http://dev.clojure.org/jira/browse/TEMJVM
[guidelines]: http://dev.clojure.org/display/community/Guidelines+for+Clojure+Contrib+committers
[wiki]: http://dev.clojure.org/
